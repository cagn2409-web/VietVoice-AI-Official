package vn.ca.vietvoiceoffline;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.StatFs;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.Locale;

/** Direct-to-private-storage model download with resume, TLS and upstream LFS SHA-256 verification. */
final class AutoModelInstaller {
 private AutoModelInstaller(){}
 static final long RESERVE=512L*1024*1024;
 static final long MAX_BYTES=2600L*1000*1000;
 static final String PREF_ID="auto_model_partial_id";
 static final class Remote {
  final long bytes;final String sha256;
  Remote(long bytes,String sha256){this.bytes=bytes;this.sha256=sha256;}
 }
 private static HttpURLConnection connect(String uri,String method) throws IOException {
  URL url=new URL(uri);
  if(!"https".equalsIgnoreCase(url.getProtocol()))throw new IOException("Chỉ tải model bằng HTTPS");
  HttpURLConnection conn=(HttpURLConnection)url.openConnection();
  conn.setConnectTimeout(30000);conn.setReadTimeout(60000);
  conn.setRequestMethod(method);conn.setRequestProperty("User-Agent","VietVoice-AutoModel/1.3");
  return conn;
 }
 private static long number(String s){try{return Long.parseLong(s);}catch(Exception e){return -1;}}
 static String cleanSha(String s){
  if(s==null)return "";s=s.replace("\"","").trim();
  return s.matches("(?i)[0-9a-f]{64}")?s.toLowerCase(Locale.ROOT):"";
 }
 static Remote inspect(String url)throws IOException {
  HttpURLConnection c=connect(url,"HEAD");c.setInstanceFollowRedirects(false);
  try{
   int code=c.getResponseCode();
   if(code!=200&&code!=302&&code!=307)throw new IOException("Máy chủ model từ chối tải: HTTP "+code);
   long bytes=number(c.getHeaderField("X-Linked-Size"));
   if(bytes<=0)bytes=c.getContentLengthLong();
   String hash=cleanSha(c.getHeaderField("X-Linked-Etag"));
   if(hash.isEmpty())hash=cleanSha(c.getHeaderField("ETag"));
   // HF LFS metadata may be unavailable; do not silently install unchecked weights.
   if(bytes<64L*1024*1024||bytes>MAX_BYTES)throw new IOException("Không xác minh được dung lượng model từ máy chủ");
   if(hash.isEmpty())throw new IOException("Máy chủ chưa trả SHA-256, không cài model chưa kiểm chứng");
   return new Remote(bytes,hash);
  }finally{c.disconnect();}
 }
 static void install(Context context)throws Exception {
  Context c=context.getApplicationContext();
  DirectModelCatalog.Spec choice=DirectModelCatalog.choose(HeavyModelStore.totalMemory(c));
  File dst=HeavyModelStore.model(c),dir=HeavyModelStore.dir(c),part=new File(dir,"official-model.download");
  if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Không tạo được thư mục AI");
  SharedPreferences prefs=c.getSharedPreferences("model_downloads",0);
  String previousId=prefs.getString(PREF_ID,"");
  if(!choice.id.equals(previousId)&&part.exists()&&!part.delete())throw new IOException("Không xóa được phần tải cũ");
  prefs.edit().putString(PREF_ID,choice.id).apply();
  State.setup("Đang kiểm tra file gốc: "+choice.display);
  Remote meta=inspect(choice.url);
  if(prefs.getString("installed_sha","").equals(meta.sha256)&&dst.length()==meta.bytes){
   State.setup("Model "+choice.display+" đã tải xong; không phải tải lại.");return;
  }
  long downloaded=part.length();
  if(downloaded>meta.bytes){if(!part.delete())throw new IOException("Không đặt lại được phần tải lỗi");downloaded=0;}
  if(new StatFs(dir.getAbsolutePath()).getAvailableBytes() < (meta.bytes-downloaded)+RESERVE){
   throw new IOException(String.format(Locale.ROOT,"Thiếu dung lượng. Cần thêm khoảng %.1f GB trống để tải %s.",
    ((meta.bytes-downloaded)+RESERVE-new StatFs(dir.getAbsolutePath()).getAvailableBytes())/1073741824.0,choice.display));
  }
  HttpURLConnection conn=connect(choice.url,"GET");
  if(downloaded>0)conn.setRequestProperty("Range","bytes="+downloaded+"-");
  long done=downloaded,last=0;
  try{
   int status=conn.getResponseCode();
   if(status!=200&&status!=206)throw new IOException("Link tải model lỗi: HTTP "+status);
   if(status==206){
    String range=conn.getHeaderField("Content-Range");
    if(range==null||!range.startsWith("bytes "+downloaded+"-"))throw new IOException("Máy chủ không hỗ trợ tải tiếp đúng vị trí");
   }else done=0; // Server ignored Range; overwrite the partial file.
   String mime=conn.getContentType();
   if(mime!=null&&(mime.startsWith("text/html")||mime.startsWith("application/json")))throw new IOException("Máy chủ trả trang web thay vì model AI");
   try(InputStream in=new BufferedInputStream(conn.getInputStream(),65536);
       OutputStream out=new BufferedOutputStream(new FileOutputStream(part,done!=0),65536)){
    byte[] buf=new byte[65536];int n;
    while((n=in.read(buf))!=-1){
     if(Thread.currentThread().isInterrupted())throw new IOException("Tải đã bị ngắt");
     done+=n;if(done>meta.bytes)throw new IOException("Model vượt kích thước dự kiến");
     out.write(buf,0,n);
     long now=System.currentTimeMillis();if(now-last>=1000){last=now;
      State.setup(String.format(Locale.ROOT,"Đang tải %s: %d%% (%d/%d MB)\nGiữ VietVoice mở; mạng ngắt có thể tải tiếp.",
        choice.display,done*100/meta.bytes,done/1048576,meta.bytes/1048576));
     }
    }
   }
  }finally{conn.disconnect();}
  if(part.length()!=meta.bytes)throw new IOException("Tải chưa đầy đủ; bấm lại để tiếp tục");
  State.setup("Đã tải xong, đang kiểm tra SHA-256…");
  if(!sha256(part).equals(meta.sha256)){part.delete();throw new IOException("Checksum không đúng; đã xóa file lỗi");}
  if(dst.exists()&&!dst.delete())throw new IOException("Không thể thay model đã cài");
  if(!part.renameTo(dst))throw new IOException("Không thể chuyển model vào thư mục ứng dụng");
  prefs.edit().putString("installed_sha",meta.sha256).putString("installed_id",choice.id).remove(PREF_ID).apply();
  State.setup("Đã cài "+choice.display+". Sẵn sàng thử dịch trực tiếp Nhật/Trung/Hàn → Việt.");
 }
 private static String sha256(File f)throws Exception{
  MessageDigest hash=MessageDigest.getInstance("SHA-256");
  try(InputStream in=new BufferedInputStream(new FileInputStream(f),65536)){
   byte[] buf=new byte[65536];for(int n;(n=in.read(buf))!=-1;)hash.update(buf,0,n);
  }
  StringBuilder s=new StringBuilder();for(byte b:hash.digest())s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();
 }
}
