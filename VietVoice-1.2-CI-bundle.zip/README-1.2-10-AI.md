# VietVoice AI 1.2 · Ten AI specialists · No ML Kit

## Những gì đã thay đổi trong mã nguồn
- Xóa **tất cả** dependency ML Kit (dịch, OCR, mặt/pose/cảnh). Không còn đường dịch qua tiếng Anh.
- Thay OCR Nhật/Trung/Hàn bằng **Tesseract4Android** dùng tessdata_fast jpn/chi_sim/kor; tải gói trong app lần đầu và giữ để dùng offline.
- ASR giữ SenseVoice và Whisper với sherpa-onnx (chọn một chế độ theo tài nguyên máy).
- Scene AI phát hiện mức thay đổi khung hình và chuyển ảnh JPEG cho LiteRT-LM khi model hỗ trợ vision. **Không tuyên bố nhận mặt, cử chỉ, hành động.**
- Dịch trực tiếp bằng LiteRT-LM `.litertlm`; thêm bước Reviewer AI thứ hai khi bật Quality Guard. Không gửi câu gốc sang bất kỳ API đám mây nào.
- 10 vai trò `TenAiModules` bao gồm SenseVoice, Whisper, Tesseract, Scene, Context, Direct, Adult, Reviewer, Voice, Coordinator. ĐÂY LÀ 10 BỘ PHẬN CHUYÊN TRÁCH, KHÔNG PHẢI 10 MÔ HÌNH LLM LỚN RIÊNG BIỆT.

## Chuẩn bị
1. Build Android bằng SDK 35, JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3 (xem workflow GitHub).
2. Trong app chọn `Tải dữ liệu & hoàn thiện app` (nhận giọng, OCR và giọng Việt); các file jpn/chi_sim/kor của tessdata_fast tải từ kho chính thức tesseract-ocr.
3. Chọn `Nhập model AI nặng (.litertlm)` để chép mô hình tương thích với phiên bản LiteRT-LM hiện có.
4. Chọn ngôn ngữ, cấp quyền thu âm/chia sẻ màn hình, bắt đầu phiên dịch.

## Ranh giới chất lượng
- Trên Redmi 13C, 10 bộ phận không thể tương đương 10 mô hình nhiều GB chạy đồng thời. Chỉ 1 LiteRT-LM inference tại một thời điểm. Lượt Reviewer AI thứ hai làm tăng độ trễ.
- Không bảo đảm dịch đúng 100%, không khẳng định mã hiện build thành công khi chưa có SDK/toolchain.
- Không khẳng định OCR Tesseract tốt bằng PP-OCRv6; chất lượng phụ thuộc ngôn ngữ, font và ảnh video. Ưu tiên kiểm thử 3 ngôn ngữ trên thiết bị thật.
- Không thêm model `.litertlm` vào ZIP. Dù không gọi tiếng Anh, không thể chứng minh nội bộ mô hình không dùng bất kỳ biểu diễn ngôn ngữ chung nào.
