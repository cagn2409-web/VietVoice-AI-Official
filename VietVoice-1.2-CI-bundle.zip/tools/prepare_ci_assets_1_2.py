#!/usr/bin/env python3
"""Restore *only* external binary build assets for VietVoice AI 1.2.

The source CI bundle deliberately excludes large AAR/ONNX/TFLite files.
CI validates SHA-256 checksums before trying to build an APK.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def download(url: str, destination: Path, sha256: str | None = None):
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.with_name(destination.name + ".part")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "VietVoice-CI-1.2"})
        h = hashlib.sha256()
        with urllib.request.urlopen(req, timeout=100) as response, tmp.open("wb") as out:
            while chunk := response.read(256 * 1024):
                out.write(chunk)
                h.update(chunk)
        if sha256 and h.hexdigest().lower() != sha256.lower():
            raise ValueError(f"SHA-256 mismatch for {destination.name}")
        tmp.replace(destination)
    finally:
        tmp.unlink(missing_ok=True)


def main():
    assets = ROOT / "app/src/main/assets"
    download(
        "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx",
        assets / "silero_vad.onnx",
        "9e2449e1087496d8d4caba907f23e0bd3f78d91fa552479bb9c23ac09cbb1fd6",
    )
    download(
        "https://storage.googleapis.com/download.tensorflow.org/models/tflite/task_library/audio_classification/android/lite-model_yamnet_classification_tflite_1.tflite",
        assets / "yamnet.tflite",
        "10c95ea3eb9a7bb4cb8bddf6feb023250381008177ac162ce169694d05c317de",
    )

    api = "https://api.github.com/repos/k2-fsa/sherpa-onnx/releases/tags/v1.13.8"
    req = urllib.request.Request(api, headers={"User-Agent": "VietVoice-CI-1.2"})
    with urllib.request.urlopen(req, timeout=30) as response:
        release = json.load(response)
    asset = next(a for a in release["assets"] if a["name"] == "sherpa-onnx-1.13.8.aar")
    sha = (asset.get("digest") or "").removeprefix("sha256:") or None
    libs = ROOT / "app/libs"
    original = libs / "sherpa-original.aar"
    try:
        download(asset["browser_download_url"], original, sha)
        subprocess.run(
            ["python3", str(ROOT / "tools/isolate_sherpa_runtime.py"), str(original),
             str(libs / "sherpa-onnx-1.13.8.aar"), "patchelf"],
            check=True,
        )
    finally:
        original.unlink(missing_ok=True)
    print("Binary assets restored and checked")


if __name__ == "__main__":
    main()
