# VietVoice AI 1.1 — Direct Vietnamese translation (source checkpoint)

## What changed

This is an updated source project based on **VietVoice AI 1.0 Official**. It offers **Japanese / Chinese / Korean -> Vietnamese** translation in a separate DIRECT mode that uses a local LiteRT-LM LLM, without a call to the ML Kit English-pivot translator. The fast ML Kit mode is still available only when the user chooses it.

**Important:** the direct mode requires a user-imported `.litertlm` model compatible with the installed LiteRT-LM Android dependency. There is no model packaged inside this project. Accuracy is not guaranteed by the prompt: compare results with source transcripts and evaluate model language support before using professionally.

## Build via Android Studio or GitHub Actions

1. Open repository root (`VietVoiceOffline/`) in Android Studio. Android SDK 35, Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3.
2. Run `gradle :app:testDebugUnitTest` and `gradle :app:assembleRelease` (or use the existing GitHub Actions build). Note: the included testing signing key is not appropriate for public release.
3. On Android install the APK produced by that build. Configure speech, OCR and voice data via the app's existing download action.
4. Choose `SÁT NGHĨA` (default), then import a LiteRT-LM `.litertlm` model. This import is mandatory and the app refuses to translate directly without it.
5. Add `từ gốc = nghĩa Việt` glossary pairs, enable adult dialogue context if applicable, choose ja/zh/ko, then start the video. Disable `Ưu tiên theo kịp video` for maximum temporal tolerance.
6. To allow English-pivot translation, consciously change to `NHANH`.

## Privacy and limitations

- The direct text inference occurs locally via LiteRT-LM, assuming that the imported model can be loaded and runs as expected. No cloud API key is needed for this mode.
- Android and apps may forbid screen or playback audio capture; subtitles/ASR are only as accurate as the data available.
- The app cannot identify whether performers in an adult film are 18+; use adult-dialogue mode only with adult material.
- English is not used as an explicit intermediary stage in the direct pipeline, but no one can assert that internal learned representations never rely on English.
- Output may contain translation errors or hallucinations and inference may be slow or fail on low-RAM devices; test on-device before relying on results.
- Release is not certified or signed for public distribution.

## Testing in this checkpoint

17 Java smoke checks run and passed. Full Android Gradle build and device test were not possible in this environment (Android SDK / Gradle unavailable). See `BUILD-STATUS-1.1.txt`.
