# VietVoice AI 1.1 — Source-to-Vietnamese offline

## Chức năng đã nối trong mã nguồn

- Mặc định **SÁT NGHĨA / dịch trực tiếp** cho ja / zh / ko → vi bằng model local LiteRT-LM `.litertlm`.
- **Không gọi ML Kit** trong đường dịch trực tiếp. Nếu model không có, lỗi hoặc quá thời gian, chỉ hiển thị lỗi; tuyệt đối không đổi âm thầm sang bộ dịch trung gian Anh.
- Bật/tắt ngữ cảnh lời thoại người lớn (chỉ dành cho nội dung người trưởng thành). Prompt giữ tiếng lóng, phủ định, mức lịch sự, lời từ chối/đồng thuận, không làm nhẹ hoặc bịa nội dung.
- Bảng thuật ngữ gốc = Việt sửa được trong app; ngữ cảnh hội thoại và hình hỗ trợ có giới hạn.
- Bộ nhanh ML Kit vẫn có để người dùng **chủ động** chọn và có cảnh báo dùng tiếng Anh trung gian.
- Cập nhật versionCode 110 / versionName 1.1.0-direct, phép thử thuần Java.

## Cách sử dụng

1. Dùng nút **Tải dữ liệu & hoàn thiện app** cho OCR, ASR, TTS và các gói phụ trợ (phần tải ML Kit cũ có thể vẫn đi kèm).
2. Chọn **SÁT NGHĨA**, tải model định dạng `.litertlm` tương thích LiteRT-LM, rồi nhập model vào app.
3. Chọn Nhật/Trung/Hàn, bật ngữ cảnh 18+ nếu dịch đối thoại người trưởng thành, thêm thuật ngữ cần giữ.
4. Tắt **Ưu tiên theo kịp video** khi muốn dành thời gian xử lý lâu hơn.
5. Cấp quyền chia sẻ màn hình; nội dung hạn chế capture theo Android có thể không dịch được.

## Giới hạn, không được ngộ nhận

- Chưa chứng minh chất lượng trực tiếp vượt máy dịch khác: phụ thuộc model và chất lượng nhận dạng lời nói/OCR. Một số model cục bộ không đủ năng lực tiếng Việt, Nhật, Trung hoặc Hàn.
- Không thể cam kết tránh mọi lỗi từ vựng, xưng hô, hoặc phát hiện tuổi người trong video.
- Đường dịch tránh *bước trung gian tiếng Anh của hệ thống*; không thể khẳng định nội suy ngôn ngữ bên trong mô hình nơ-ron.
- Có thể chậm 10–120 giây/câu, nóng máy và mất câu khi tải cao; cần thử trên thiết bị thật.
- **Chưa tạo APK tại phiên chỉnh source nếu thiếu Android SDK/Gradle.** Bản `.zip` là mã nguồn, không phải APK cài được.
- `signing/vietvoice-test.keystore` chỉ dành cho bản thử nghiệm. Không dùng bản này phát hành rộng rãi.
