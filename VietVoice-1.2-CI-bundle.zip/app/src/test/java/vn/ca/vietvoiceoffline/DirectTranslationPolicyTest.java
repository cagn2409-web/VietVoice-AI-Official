package vn.ca.vietvoiceoffline;
import org.junit.Test;
import static org.junit.Assert.*;
public class DirectTranslationPolicyTest {
 @Test public void onlyDirectWithModel(){
  assertNotNull(DirectTranslationPolicy.prerequisites(false,true,true,true,true,false,true));
  assertNull(DirectTranslationPolicy.prerequisites(true,true,true,true,true,false,true));
 }
 @Test public void ocrAndAsrHaveIndependentReadiness(){
  assertNotNull(DirectTranslationPolicy.prerequisites(true,true,false,false,true,false,true));
  assertNull(DirectTranslationPolicy.prerequisites(true,false,false,true,true,false,true));
  assertNotNull(DirectTranslationPolicy.prerequisites(true,false,true,true,false,false,true));
 }
 @Test public void noPivotInDirectOrReviewerPrompt(){
  String p=HeavyPrompt.buildDirect("ko","원문","scene","history","term=nghĩa",true);
  String r=HeavyPrompt.buildVerifyDirect("ja","やめて","Dừng lại","history","",true);
  assertTrue(p.contains("KHÔNG dịch qua tiếng Anh"));assertFalse(p.contains("BẢN DỊCH NHANH"));
  assertTrue(r.contains("Không dùng tiếng Anh"));assertTrue(r.contains("やめて"));
 }
}
