package vn.ca.vietvoiceoffline;
import android.content.Context;
import java.io.*;
import java.net.*;

/** Tesseract training data is downloaded on demand. No dependency on ML Kit. */
final class TessdataStore {
 private TessdataStore() {}
 private static final String ROOT="https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/";
 static String code(String language){switch(language){case "ja":return "jpn";case "ko":return "kor";case "zh":return "chi_sim";default:throw new IllegalArgumentException("Ngôn ngữ không hỗ trợ: "+language);}}
 static File base(Context c){return new File(c.getFilesDir(),"tesseract");}
 static File file(Context c,String language){return new File(new File(base(c),"tessdata"),code(language)+".traineddata");}
 static boolean ready(Context c,String language){File f=file(c,language);return f.isFile()&&f.length()>1024*1024;}
 static void installAll(Context c) throws IOException{for(String lang:new String[]{"ja","zh","ko"})install(c,lang);}
 static void install(Context c,String language) throws IOException{
  File dest=file(c,language);if(ready(c,language))return;
  File dir=dest.getParentFile();if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Không tạo được tessdata");
  File part=new File(dest.getAbsolutePath()+".download");String name=code(language)+".traineddata";
  State.setup("OCR Tesseract: đang tải "+name);
  HttpURLConnection conn=(HttpURLConnection)new URL(ROOT+name).openConnection();
  conn.setConnectTimeout(25000);conn.setReadTimeout(60000);conn.setInstanceFollowRedirects(true);
  try{if(conn.getResponseCode()!=200)throw new IOException("OCR HTTP "+conn.getResponseCode());
   long count=0;try(InputStream in=new BufferedInputStream(conn.getInputStream());OutputStream out=new BufferedOutputStream(new FileOutputStream(part))){
    byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);count+=n;if(count>100L*1024*1024)throw new IOException("Tessdata quá lớn");}}
   if(part.length()<1024*1024)throw new IOException("Tessdata quá nhỏ; tải lỗi");
   if(dest.exists()&&!dest.delete())throw new IOException("Không thay được tessdata cũ");
   if(!part.renameTo(dest))throw new IOException("Không thể lưu tessdata");
  }finally{conn.disconnect();if(part.exists())part.delete();}
 }
}
