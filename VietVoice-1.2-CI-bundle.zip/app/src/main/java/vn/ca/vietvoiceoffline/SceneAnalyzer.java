package vn.ca.vietvoiceoffline;
import android.graphics.Bitmap;
import android.graphics.Color;
import java.io.ByteArrayOutputStream;
/** Light visual-signal processor: does NOT infer people, poses or actions. */
final class SceneAnalyzer implements AutoCloseable {
 interface Sink {void accept(SceneContext c);}
 private final Sink sink;private boolean closed;private int[] previous;
 SceneAnalyzer(Sink sink){this.sink=sink;}
 synchronized void analyze(Bitmap frame,long timeMs){if(frame==null)return;try{if(closed)return;
  int[] now=new int[32*18];Bitmap small=Bitmap.createScaledBitmap(frame,32,18,false);small.getPixels(now,0,32,0,0,32,18);small.recycle();
  int[] luma=new int[now.length];for(int i=0;i<now.length;i++)luma[i]=(Color.red(now[i])*3+Color.green(now[i])*6+Color.blue(now[i]))/10;
  float motion=0;if(previous!=null){long d=0;for(int i=0;i<luma.length;i++)d+=Math.abs(luma[i]-previous[i]);motion=Math.min(1f,d/(255f*luma.length));}previous=luma;
  String hint=motion>.2f?"Khung hình thay đổi mạnh":motion>.08f?"Khung hình có chuyển động":"";
  ByteArrayOutputStream out=new ByteArrayOutputStream(90000);byte[] shot=frame.compress(Bitmap.CompressFormat.JPEG,68,out)?out.toByteArray():null;
  // Motion alone is not enough to infer consent, emotion, identities or actions.
  if(sink!=null)sink.accept(new SceneContext(timeMs,hint,hint.isEmpty()?0f:.4f,shot));
 }finally{frame.recycle();}}
 public synchronized void close(){closed=true;previous=null;}
}
