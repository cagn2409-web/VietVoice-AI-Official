package vn.ca.vietvoiceoffline;
import android.content.Context;
import java.util.concurrent.*;

/** Single-flight LLM queue: if the heavy model is busy, current realtime translation falls back immediately. */
final class HeavyTranslationManager implements AutoCloseable{
 interface Callback{void done(String result,long elapsedMs,String error);}
 private final ExecutorService executor=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"heavy-ai");t.setPriority(Thread.NORM_PRIORITY-1);return t;});
 private final HeavyTranslator translator;private volatile boolean busy,closed,ready,initializing=true;private volatile String initError="";
 HeavyTranslationManager(Context c){translator=new HeavyTranslator(c.getApplicationContext(),HeavyModelStore.model(c).getAbsolutePath());executor.execute(()->{try{translator.initialize();ready=!closed;}catch(Throwable t){initError=State.error(t);}finally{initializing=false;if(closed)try{translator.close();}catch(Throwable ignored){}}});}
 boolean ready(){return ready&&!closed;}
 String status(){return ready?"Heavy AI sẵn sàng":initError.isEmpty()?"Heavy AI đang nạp model":"Heavy AI lỗi: "+initError;}
 synchronized boolean refine(String language,String source,String fastVi,String scene,String history,byte[] sceneImage,Callback cb){
  if(closed||!ready||busy)return false;busy=true;long start=android.os.SystemClock.elapsedRealtime();
  executor.execute(()->{String out="",err="";try{out=translator.translate(language,source,fastVi,scene,history,sceneImage);}catch(Throwable t){err=State.error(t);}finally{busy=false;if(closed)try{translator.close();}catch(Throwable ignored){}}if(!closed&&cb!=null)cb.done(out,android.os.SystemClock.elapsedRealtime()-start,err);});return true;
 }
 /** Wait for direct-model initialization and inference without ever using the pivot translator. */
 String translateDirect(String language,String source,String scene,String history,String glossary,
                        boolean adultContext,byte[] sceneImage,long timeoutMs) throws Exception{
  if(closed)throw new IllegalStateException("Heavy AI đã đóng");
  Future<String> task=executor.submit(()->{
   if(!ready)throw new IllegalStateException(status());
   return translator.translateDirect(language,source,scene,history,glossary,adultContext,sceneImage);
  });
  try{return task.get(timeoutMs,TimeUnit.MILLISECONDS);}
  catch(TimeoutException e){task.cancel(true);throw new TimeoutException("Model trực tiếp xử lý quá lâu. Thử đoạn ngắn hoặc model nhẹ hơn.");}
  catch(ExecutionException e){Throwable cause=e.getCause();if(cause instanceof Exception)throw (Exception)cause;throw new IllegalStateException(cause);}
 }
 String verifyDirect(String language,String source,String draft,String history,String glossary,
                     boolean adultContext,long timeoutMs) throws Exception {
  if(closed)throw new IllegalStateException("Heavy AI đã đóng");
  Future<String> task=executor.submit(()->{
   if(!ready)throw new IllegalStateException(status());
   return translator.verifyDirect(language,source,draft,history,glossary,adultContext);
  });
  try{return task.get(timeoutMs,TimeUnit.MILLISECONDS);}
  catch(TimeoutException e){task.cancel(true);throw new TimeoutException("AI kiểm định xử lý quá lâu");}
  catch(ExecutionException e){Throwable c=e.getCause();if(c instanceof Exception)throw (Exception)c;throw new IllegalStateException(c);}
 }
 @Override public synchronized void close(){closed=true;ready=false;executor.shutdownNow();if(!busy&&!initializing)try{translator.close();}catch(Throwable ignored){}}
}
