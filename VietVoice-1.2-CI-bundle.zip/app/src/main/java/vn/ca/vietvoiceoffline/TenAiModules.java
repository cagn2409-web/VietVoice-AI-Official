package vn.ca.vietvoiceoffline;
import android.content.Context;
/** Ten connected specialists, not ten simultaneously-loaded large language models. */
final class TenAiModules {
 static final String[] NAME={"01 SenseVoice · nghe lời thoại", "02 Whisper · nhận giọng dự phòng", "03 Tesseract OCR · đọc phụ đề", "04 Scene AI · chuyển cảnh", "05 Context AI · nhớ hội thoại", "06 Direct AI · dịch Nhật/Trung/Hàn → Việt", "07 Adult Language AI · từ lóng và sắc thái 18+", "08 Reviewer AI · kiểm định lượt hai", "09 Voice AI · giọng Việt", "10 Coordinator AI · giảm tải, chống trễ"};
 static final String[] CORE={"sherpa-onnx + SenseVoice", "sherpa-onnx + Whisper", "Tesseract4Android", "frame-motion + multimodal LLM (nếu có)", "DialogueContext + LLM", "LiteRT-LM", "LLM + glossary", "LiteRT-LM second pass", "Piper/VoicePack", "AiRouter + QualityGate"};
 private TenAiModules(){}
 static int count(){return NAME.length;}
 static String status(Context c){StringBuilder b=new StringBuilder();for(int i=0;i<NAME.length;i++){
  b.append(NAME[i]).append("\n  ").append(CORE[i]).append(" · ");
  switch(i){case 0:b.append(RecognitionPack.ready(c)?"model ASR sẵn sàng":"cần tải model");break;
   case 1:b.append(ModelStore.asrPresent(c)?"model sẵn sàng":"cần tải model");break;
   case 2:b.append((TessdataStore.ready(c,"ja")&&TessdataStore.ready(c,"zh")&&TessdataStore.ready(c,"ko"))?"dữ liệu 3 ngôn ngữ sẵn sàng":"cần tải tessdata");break;
   case 5:case 6:case 7:b.append(HeavyModelStore.ready(c)?"đã có file LLM; cần kiểm tra tương thích":"cần import model");break;
   default:b.append("đã tích hợp trong source");break;
  }b.append("\n");
 }return b.toString();}
}
