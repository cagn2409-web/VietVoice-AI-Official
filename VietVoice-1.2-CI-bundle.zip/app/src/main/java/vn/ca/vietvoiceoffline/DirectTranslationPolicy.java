package vn.ca.vietvoiceoffline;
/** No English pivot engine is available in this build. */
final class DirectTranslationPolicy {
 private DirectTranslationPolicy(){}
 static String prerequisites(boolean modelReady,boolean needsOcr,boolean ocrReady,boolean needsAsr,boolean asrReady,boolean needsClone,boolean cloneReady){
  if(!modelReady)return "Chưa có model LLM .litertlm để dịch trực tiếp. Không thể chuyển qua tiếng Anh.";
  if(needsOcr&&!ocrReady)return "Thiếu dữ liệu OCR Tesseract cho ngôn ngữ đã chọn. Bấm Tải dữ liệu.";
  if(needsAsr&&!asrReady)return "Thiếu AI nhận dạng giọng. Bấm Tải dữ liệu.";
  if(needsClone&&!cloneReady)return "Chưa tải dữ liệu mô phỏng giọng. Bấm Tải dữ liệu.";
  return null;
 }
}
