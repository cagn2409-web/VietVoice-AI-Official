package vn.ca.vietvoiceoffline;
import android.content.Context;
import android.graphics.*;
import android.hardware.display.*;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import com.googlecode.tesseract.android.TessBaseAPI;

/** Screen OCR via offline Tesseract4Android; one recognizer thread, no ML Kit. */
final class ScreenReader implements AutoCloseable {
 interface Sink { void accept(String text, boolean fresh); }
 interface FrameSink { void accept(Bitmap frame, long timeMs); }
 private final Context context;private final MediaProjection projection;private final Sink sink;private final FrameSink frameSink;
 private final TessBaseAPI ocr;private final HandlerThread thread=new HandlerThread("tesseract-subtitles");private final Handler handler;
 private SubtitleGate gate=new SubtitleGate();private Rect lastRegion;private ImageReader reader;private VirtualDisplay display;
 private volatile boolean stopped;private long next,lastText=SystemClock.elapsedRealtime(),nextScene;private int width,height;
 private java.nio.ByteBuffer cropBytes;
 ScreenReader(Context c,MediaProjection p,String language,Sink s){this(c,p,language,s,null);}
 ScreenReader(Context c,MediaProjection p,String language,Sink s,FrameSink f){
  context=c;projection=p;sink=s;frameSink=f;
  if(!TessdataStore.ready(c,language))throw new IllegalStateException("Thiếu OCR "+TessdataStore.code(language)+".traineddata. Hãy tải dữ liệu trước.");
  ocr=new TessBaseAPI();if(!ocr.init(TessdataStore.base(c).getAbsolutePath(),TessdataStore.code(language))){ocr.recycle();throw new IllegalStateException("Không khởi tạo được Tesseract OCR");}
  ocr.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);
  thread.start();handler=new Handler(thread.getLooper());
 }
 void start(){DisplayMetrics m=new DisplayMetrics();context.getSystemService(WindowManager.class).getDefaultDisplay().getRealMetrics(m);width=m.widthPixels;height=m.heightPixels;
  reader=makeReader(width,height);display=projection.createVirtualDisplay("VietVoice subtitle OCR",width,height,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),new VirtualDisplay.Callback(){},handler);
 }
 private ImageReader makeReader(int w,int h){ImageReader r=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);r.setOnImageAvailableListener(this::frame,handler);return r;}
 void resize(int w,int h){handler.post(()->{if(stopped||display==null||w<=0||h<=0||(w==width&&h==height))return;ImageReader old=reader;width=w;height=h;reader=makeReader(w,h);display.setSurface(null);display.resize(w,h,context.getResources().getDisplayMetrics().densityDpi);display.setSurface(reader.getSurface());old.close();});}
 private void frame(ImageReader source){Image image=null;Bitmap padded=null,crop=null,visible=null;
  try{image=source.acquireLatestImage();long now=SystemClock.elapsedRealtime();if(image==null||stopped||RegionPicker.active||now<next)return;
   next=now+650;Image.Plane plane=image.getPlanes()[0];int w=image.getWidth(),h=image.getHeight(),pixel=plane.getPixelStride(),row=plane.getRowStride();if(pixel!=4)throw new IllegalStateException("Cần khung RGBA_8888");
   Rect region=SubtitleRegion.get(context,w,h);if(!region.equals(lastRegion)){gate=new SubtitleGate();lastRegion=new Rect(region);}
   boolean scene=frameSink!=null&&now>=nextScene;
   if(scene){nextScene=now+1300;int paddedWidth=row/pixel;java.nio.ByteBuffer pixels=plane.getBuffer();pixels.rewind();padded=Bitmap.createBitmap(paddedWidth,h,Bitmap.Config.ARGB_8888);padded.copyPixelsFromBuffer(pixels);
    crop=Bitmap.createBitmap(padded,region.left,region.top,region.width(),region.height());visible=Bitmap.createBitmap(padded,0,0,w,h);
    int target=Math.min(640,Math.max(320,w)),th=Math.max(180,Math.round(h*(target/(float)w)));Bitmap shot=Bitmap.createScaledBitmap(visible,target,th,true);
    try{frameSink.accept(shot,now);}catch(Throwable e){if(!shot.isRecycled())shot.recycle();State.status("Scene AI lỗi: "+State.error(e));}
   }else crop=copyCrop(plane,region);
   ocr.setImage(crop);String raw=ocr.getUTF8Text();ocr.clear();raw=raw==null?"":raw.replaceAll("\\s+"," ").trim();
   if(!raw.matches("(?s).*[\\p{IsHan}\\p{IsHiragana}\\p{IsKatakana}\\p{IsHangul}].*"))raw="";
   if(!raw.isEmpty())lastText=SystemClock.elapsedRealtime();else if(SystemClock.elapsedRealtime()-lastText>12000)State.status("Chưa đọc thấy phụ đề. Hãy khoanh vùng hoặc dùng âm thanh.");
   String stable=gate.accept(raw);if(raw.length()<=700&&gate.isStable(raw))sink.accept(raw,stable!=null);else sink.accept("",false);
  }catch(Exception|LinkageError e){if(!stopped)State.status("OCR Tesseract: "+State.error(e));}
  finally{if(image!=null)image.close();if(crop!=null&&!crop.isRecycled())crop.recycle();if(visible!=null&&!visible.isRecycled())visible.recycle();if(padded!=null&&!padded.isRecycled())padded.recycle();}
 }
 private Bitmap copyCrop(Image.Plane plane,Rect region){int rw=region.width(),rh=region.height(),bytes=rw*rh*4;
  if(cropBytes==null||cropBytes.capacity()<bytes)cropBytes=java.nio.ByteBuffer.allocateDirect(bytes);cropBytes.clear();java.nio.ByteBuffer src=plane.getBuffer().duplicate();
  int stride=plane.getRowStride(),pixel=plane.getPixelStride(),width=rw*pixel;
  for(int y=region.top;y<region.bottom;y++){int start=y*stride+region.left*pixel;src.position(start);src.limit(start+width);cropBytes.put(src);src.limit(src.capacity());}
  cropBytes.flip();Bitmap out=Bitmap.createBitmap(rw,rh,Bitmap.Config.ARGB_8888);out.copyPixelsFromBuffer(cropBytes);return out;
 }
 public void close(){handler.post(()->{stopped=true;if(display!=null)display.release();if(reader!=null)reader.close();ocr.recycle();thread.quitSafely();});}
}
