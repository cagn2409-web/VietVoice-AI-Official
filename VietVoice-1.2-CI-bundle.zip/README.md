# VietVoice AI 1.2 — 10 mô-đun chuyên trách / NO ML KIT

Đọc `README-1.2-10-AI.md` để biết kiến trúc, cấu hình, giới hạn và cách build. Đây là **mã nguồn**, không phải APK đã được kiểm chứng.
