# VietVoice AI 1.2.1 — 10 AI — Android build checkpoint

## Trạng thái (09/10/2026)
- Đã sửa lỗi Java `unclosed string literal` trong `TenAiModules.java`, khiến nguyên gói 1.2 trước đó không thể build được.
- Đã biên dịch và chạy **53 bài kiểm thử Java thuần: 53 đạt, 0 lỗi** bằng bộ test runner tối giản để kiểm tra logic khi thiếu Android SDK.
- Đã kiểm tra cấu hình CI và script tải asset bằng parser; **chưa build APK bằng Gradle**, chưa kiểm tra biên dịch mã Android + Kotlin trong môi trường đầy đủ.
- Chưa thử trên Redmi 13C, chưa đo chất lượng dịch và tốc độ thực tế. Không thể cam kết dịch sát nghĩa nếu chưa nhập và đánh giá mô hình `.litertlm` phù hợp.

## Tạo APK bằng GitHub Actions
1. Giữ nguyên repository `cagn2409-web/VietVoice-AI-Official` hiện tại.
2. Tải file `VietVoice-1.2-CI-bundle.zip` (gói nhẹ không có 50 MB asset) trong cùng đợt bàn giao.
3. Trên GitHub, chọn `Add file` -> `Upload files`, tải **chính file ZIP** vào thư mục gốc của repo, `Commit changes` lên `main`.
4. Workflow `Build VietVoice 1.2 from source bundle` sẽ tự khởi động và cài SDK/Gradle, khôi phục asset, kiểm thử, tạo APK nếu biên dịch thành công.
5. Chọn `Actions` -> workflow -> bản chạy mới để xem log. Nếu xanh, lấy APK từ artifact `VietVoice-AI-1.2-10AI-APK` hoặc `Releases` (file VietVoice-AI-1.2-10AI.apk).

**Không cần tải AAR/ONNX/TFLite thủ công cho CI**, script `tools/prepare_ci_assets_1_2.py` dùng tài nguyên upstream có kiểm tra SHA-256 khi upstream cung cấp. Workflow *không* chứa mô hình LiteRT-LM dịch trực tiếp; model này phải nhập trong app sau khi cài.

**Lưu ý:** APK ký bằng khóa thử nghiệm cá nhân đã có trong repository. Không sử dụng khóa thử nghiệm công khai này làm khóa phát hành ứng dụng thương mại.
