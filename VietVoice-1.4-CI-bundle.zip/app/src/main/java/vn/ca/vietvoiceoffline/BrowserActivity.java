package vn.ca.vietvoiceoffline;

import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;

/** VietVoice browser: normal WebView playback + opt-in native boost for direct streams. */
public final class BrowserActivity extends Activity {
 private WebView web;
 private FrameLayout pageFrame;
 private LinearLayout chrome, root;
 private EditText address;
 private TextView info;
 private View fullScreen;
 private WebChromeClient.CustomViewCallback fullScreenExit;
 private android.content.SharedPreferences prefs;
 private boolean translating;
 private final Handler main=new Handler(Looper.getMainLooper());
 private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
 private Button button(LinearLayout holder,String title,View.OnClickListener listener){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(12);b.setOnClickListener(listener);holder.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));return b;}
 @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(Color.rgb(16,45,55));prefs=getSharedPreferences("vv_browser",0);
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(246,250,250));setContentView(root);
  chrome=new LinearLayout(this);chrome.setOrientation(LinearLayout.VERTICAL);root.addView(chrome,new LinearLayout.LayoutParams(-1,-2));
  LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);chrome.addView(top);
  address=new EditText(this);address.setTextSize(14);address.setSingleLine(true);address.setHint("Nhập link hoặc từ khóa tìm kiếm");address.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);
  top.addView(address,new LinearLayout.LayoutParams(0,dp(52),1));Button go=new Button(this);go.setText("Mở");go.setAllCaps(false);top.addView(go);go.setOnClickListener(v->navigate());
  address.setOnEditorActionListener((v,a,event)->{navigate();return true;});
  LinearLayout nav=new LinearLayout(this);chrome.addView(nav);
  button(nav,"←",v->{if(web.canGoBack())web.goBack();});button(nav,"→",v->{if(web.canGoForward())web.goForward();});
  button(nav,"⟳",v->web.reload());button(nav,"★",v->bookmark());button(nav,"Dịch chọn",v->translateSelection());
  LinearLayout actions=new LinearLayout(this);chrome.addView(actions);
  button(actions,"🎬 VIDEO BOOST",v->openVideoBoost());
  button(actions,"Dấu trang",v->showBookmarks());
  button(actions,"Riêng tư",v->privacyMenu());
  info=new TextView(this);info.setTextSize(12);info.setTextColor(0xff245D63);info.setPadding(dp(8),dp(6),dp(8),dp(6));info.setText("Tìm nguồn MP4/HLS trực tiếp để tăng đệm; trang DRM/blob không hỗ trợ.");chrome.addView(info);
  pageFrame=new FrameLayout(this);root.addView(pageFrame,new LinearLayout.LayoutParams(-1,0,1));
  web=new WebView(this);pageFrame.addView(web,new FrameLayout.LayoutParams(-1,-1));
  WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setMediaPlaybackRequiresUserGesture(false);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setAllowFileAccessFromFileURLs(false);settings.setAllowUniversalAccessFromFileURLs(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  if(Build.VERSION.SDK_INT>=26)settings.setSafeBrowsingEnabled(true);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){Uri uri=req.getUrl();String scheme=uri.getScheme();
    if("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme))return false;
    if(req.isForMainFrame())info.setText("Liên kết ngoài không được tự mở: "+scheme);return true;
   }
   @Override public void onPageFinished(WebView v,String url){address.setText(url);info.setText("VietVoice Browser • chạm VIDEO BOOST để thử tăng bộ đệm");}
   @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())info.setText("Không tải được trang: "+e.getDescription());}
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public void onProgressChanged(WebView v,int n){if(n<100)info.setText("Đang tải trang "+n+"%…");}
   @Override public void onShowCustomView(View view,CustomViewCallback callback){if(fullScreen!=null){callback.onCustomViewHidden();return;}fullScreen=view;fullScreenExit=callback;chrome.setVisibility(View.GONE);web.setVisibility(View.GONE);pageFrame.addView(view,new FrameLayout.LayoutParams(-1,-1));getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);}
   @Override public void onHideCustomView(){exitFullScreen();}
  });
  if(saved!=null)web.restoreState(saved);else web.loadUrl(prefs.getString("last_page","https://www.google.com"));
 }
 private void navigate(){String s=address.getText().toString().trim();if(s.isEmpty())return;
  if(!s.matches("(?i)^https?://.*")){if(s.contains(" ")||!s.contains(".")){try{s="https://www.google.com/search?q="+URLEncoder.encode(s,"UTF-8");}catch(Exception ignored){}}else s="https://"+s;}
  Uri uri=Uri.parse(s);if(!"http".equals(uri.getScheme())&&!"https".equals(uri.getScheme())){info.setText("Chỉ mở HTTP hoặc HTTPS");return;}
  ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);web.loadUrl(s);
 }
 private void bookmark(){String url=web.getUrl();if(url==null)return;String key="bookmark:"+Uri.encode(url);
  prefs.edit().putString(key,web.getTitle()==null?url:web.getTitle()).apply();info.setText("Đã lưu dấu trang.");}
 private void showBookmarks(){ArrayList<String> urls=new ArrayList<>();ArrayList<String> titles=new ArrayList<>();for(java.util.Map.Entry<String,?> entry:prefs.getAll().entrySet()){
  if(entry.getKey().startsWith("bookmark:")){urls.add(Uri.decode(entry.getKey().substring(9)));titles.add(String.valueOf(entry.getValue()));}}
  if(urls.isEmpty()){info.setText("Chưa có dấu trang nào. Bấm ★ để lưu.");return;}
  new AlertDialog.Builder(this).setTitle("Dấu trang VietVoice").setItems(titles.toArray(new String[0]),(d,n)->web.loadUrl(urls.get(n))).setNegativeButton("Đóng",null).show();
 }
 private void privacyMenu(){new AlertDialog.Builder(this).setTitle("Dữ liệu web VietVoice")
  .setMessage("Xóa cookie, lịch sử WebView và cache trang web trong ứng dụng này? Không xóa model AI hay cache Video Boost.")
  .setPositiveButton("Xóa dữ liệu web",(d,w)->{web.clearHistory();web.clearCache(true);WebStorage.getInstance().deleteAllData();CookieManager.getInstance().removeAllCookies(ok->info.setText("Đã yêu cầu xóa dữ liệu web."));})
  .setNegativeButton("Hủy",null).show();}
 private void openVideoBoost(){String page=web.getUrl();if(page==null)return;
  String js="(function(){const a=[];const put=u=>{if(u&&typeof u==='string'&&a.indexOf(u)<0)a.push(u)};"+
    "document.querySelectorAll('video').forEach(v=>{put(v.currentSrc);put(v.src);v.querySelectorAll('source').forEach(s=>put(s.src));});"+
    "document.querySelectorAll('a[href]').forEach(x=>{const u=x.href;if(/\\.(mp4|m3u8|mpd|webm)([?#]|$)/i.test(u))put(u)});return JSON.stringify(a.slice(0,40));})()";
  web.evaluateJavascript(js,raw->{try{Object obj=new JSONTokener(raw).nextValue();JSONArray array=new JSONArray(obj.toString());ArrayList<String> choices=new ArrayList<>();HashSet<String> seen=new HashSet<>();
   String direct=VideoUrlPolicy.acceptedUrl(page,page);if(direct!=null&&seen.add(direct))choices.add(direct);
   for(int i=0;i<array.length();i++){String url=VideoUrlPolicy.acceptedUrl(page,array.optString(i));if(url!=null&&seen.add(url))choices.add(url);}
   if(choices.isEmpty()){new AlertDialog.Builder(this).setTitle("Chưa tìm thấy luồng phát trực tiếp")
      .setMessage("Trang này có thể dùng blob, DRM, video nhúng hoặc chặn đường dẫn. Bạn vẫn xem video qua WebView bình thường; Video Boost chỉ hỗ trợ đường dẫn MP4/HLS/DASH trực tiếp.").setPositiveButton("Đã hiểu",null).show();return;}
   String[] labels=new String[choices.size()];for(int i=0;i<choices.size();i++){String x=choices.get(i);labels[i]=(i+1)+". "+(x.length()>100?x.substring(0,97)+"…":x);}
   new AlertDialog.Builder(this).setTitle("Chọn video để phát bằng Video Boost").setItems(labels,(d,n)->{
     Intent intent=new Intent(this,VideoBoostActivity.class);intent.putExtra("url",choices.get(n));intent.putExtra("referer",page);intent.putExtra("ua",web.getSettings().getUserAgentString());startActivity(intent);
   }).setNegativeButton("Hủy",null).show();
  }catch(Exception ex){info.setText("Không đọc được đường dẫn video trên trang này.");}});
 }
 private void translateSelection(){if(translating)return;web.evaluateJavascript("(function(){return String(window.getSelection()||'').slice(0,1200)})()",raw->{try{
  String s=new JSONTokener(raw).nextValue().toString().trim();if(s.isEmpty()){info.setText("Bôi đen câu Nhật/Trung/Hàn trên trang rồi bấm Dịch chọn.");return;}
  if(!HeavyModelStore.ready(this)){new AlertDialog.Builder(this).setTitle("Cần model AI")
   .setMessage("Bấm TẢI VÀ CÀI TOÀN BỘ AI ở màn hình chính trước khi dịch trực tiếp.").setPositiveButton("OK",null).show();return;}
  translating=true;info.setText("AI đang dịch đoạn bạn chọn…");
  String language=new String[]{"ja","zh","ko"}[Math.max(0,Math.min(2,getSharedPreferences("settings",0).getInt("language",0)))];
  new Thread(()->{String result,error=null;try(HeavyTranslator model=new HeavyTranslator(getApplicationContext(),HeavyModelStore.model(this).getAbsolutePath())){
    model.initialize();result=model.translateDirect(language,s,"","",getSharedPreferences("settings",0).getString("directGlossary",""),getSharedPreferences("settings",0).getBoolean("adultContext",true),null);
  }catch(Throwable t){result="";error=t.getMessage();}
   final String translated=result,err=error;runOnUiThread(()->{translating=false;info.setText(err==null?"Đã dịch đoạn đã chọn.":"Không dịch được: "+err);
     if(err==null&&!isFinishing())new AlertDialog.Builder(this).setTitle("Dịch trực tiếp → Việt").setMessage("Gốc:\n"+s+"\n\nTiếng Việt:\n"+translated).setPositiveButton("Đóng",null).show();});
  },"browser-translate-selected").start();
 }catch(Exception e){info.setText("Không lấy được văn bản đã chọn.");}});}
 private void exitFullScreen(){if(fullScreen==null)return;pageFrame.removeView(fullScreen);fullScreen=null;chrome.setVisibility(View.VISIBLE);web.setVisibility(View.VISIBLE);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);if(fullScreenExit!=null){fullScreenExit.onCustomViewHidden();fullScreenExit=null;}}
 @Override public void onBackPressed(){if(fullScreen!=null){exitFullScreen();return;}if(web.canGoBack()){web.goBack();return;}super.onBackPressed();}
 @Override protected void onSaveInstanceState(Bundle s){web.saveState(s);super.onSaveInstanceState(s);}
 @Override protected void onPause(){if(web!=null){String u=web.getUrl();if(u!=null&&u.startsWith("https://"))prefs.edit().putString("last_page",u).apply();}super.onPause();}
 @Override protected void onDestroy(){if(fullScreen!=null)exitFullScreen();if(web!=null){pageFrame.removeView(web);web.destroy();}super.onDestroy();}
}
