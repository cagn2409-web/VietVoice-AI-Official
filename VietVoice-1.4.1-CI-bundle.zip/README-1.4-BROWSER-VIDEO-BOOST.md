# VietVoice AI 1.4 — Browser Pro + Video Boost

Android WebView tích hợp trong VietVoice, có trình phát Media3 cho các liên kết phát MP4/WebM/HLS/DASH trực tiếp.

## Có trong mã nguồn

- Nút **Trình duyệt VietVoice** ở giao diện chính.
- Thanh địa chỉ/tìm kiếm, quay lại/tới, tải lại, dấu trang và xóa dữ liệu duyệt web.
- Chạy video HTML5 toàn màn hình qua WebChromeClient.
- **Video Finder** chỉ đọc URL video từ thẻ HTML5 `video`, `source`, và liên kết HTML công khai. Không giải mã/bỏ DRM, không lấy nội dung `blob:` hay link riêng của ứng dụng khác.
- **Video Boost** mở link trực tiếp bằng Media3; chọn bộ đệm mục tiêu 30/60/120 giây (có thể không đạt nếu mạng/yêu cầu máy chủ hạn chế). Cache LRU tối đa 512 MiB, hỗ trợ tua lại và xóa cache.
- Video Boost có chỉ báo số giây đệm, dung lượng cache, số lần chuyển sang trạng thái buffering; tốc độ phát 1/1.25/1.5x và Picture-in-Picture (nếu Android cho phép).
- Chọn văn bản Nhật/Trung/Hàn trên trang → **Dịch chọn** với mô hình LiteRT-LM đã tải và ưu tiên ngữ cảnh 18+. Không sử dụng tiếng Anh làm bản dịch trung gian.
- Không tự gửi Cookie của WebView sang media player, tránh vô tình gửi dữ liệu xác thực sang host khác. Video yêu cầu cookie, DRM, Widevine, `blob:` hoặc link mã hóa có thể không mở được bằng Video Boost.

## Chưa hoàn thiện trong bản 1.4

- Phụ đề kép dịch tức thì cho mọi luồng video và âm thanh thu trực tiếp từ WebView/Media3: phải phát triển cầu âm thanh/track phụ đề, thử DRM và đồng bộ thời gian.
- Tự giảm bitrate/phát hiện tất cả luồng MSE. Chế độ Smart Buffer không thể bắt máy chủ tải nhanh hơn băng thông thực.
- Chưa thử trên điện thoại thật Redmi 13C trước khi phát hành; chạy bộ kiểm thử và build Android trên GitHub Actions.

## Quyền và an toàn

WebView không bật truy cập file local, chặn mixed content và scheme lạ; Safe Browsing được bật trên phiên bản Android hỗ trợ. Video Boost chỉ chấp nhận HTTP(S) với phần mở rộng phương tiện đã hỗ trợ. Cache nằm riêng dưới `getCacheDir()` và tự giới hạn 512 MB.

## Hướng dẫn

1. Cài đè APK 1.4 (cùng chữ ký test cá nhân với các bản trước).
2. Mở VietVoice → `Trình duyệt VietVoice` → truy cập trang → phát video.
3. Với trang có link trực tiếp, bấm `VIDEO BOOST` → chọn luồng → chọn đệm 30/60/120 giây.
4. Để dịch chữ trên trang: bôi đen câu → `Dịch chọn` (yêu cầu model LiteRT-LM tải sẵn).
5. Khi trang chỉ cấp `blob:`/DRM/cookie bảo vệ, xem bằng WebView bình thường. Không thể ép chính trình phát của trang dùng cache Video Boost.
