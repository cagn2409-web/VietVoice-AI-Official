package vn.ca.vietvoiceoffline;

/** Exact publicly downloadable LiteRT-LM model files; no gated Gemma license or English pivot. */
final class DirectModelCatalog {
 static final class Spec {
  final String id, display, url;
  final long approximateBytes;
  Spec(String id, String display, String url, long approximateBytes){
   this.id=id;this.display=display;this.url=url;this.approximateBytes=approximateBytes;
  }
 }
 private DirectModelCatalog(){}
 static final Spec QUALITY=new Spec("hy-mt2-1.8b-int8", "Hy-MT2 1.8B · chuyên dịch trực tiếp",
  "https://huggingface.co/litert-community/Hy-MT2-1.8B/resolve/main/Hy-MT2-1.8B_int8.litertlm",1830L*1000*1000);
 static final Spec LIGHT=new Spec("qwen3.5-0.8b-int8", "Qwen3.5 0.8B · máy RAM thấp",
  "https://huggingface.co/litert-community/Qwen3.5-0.8B/resolve/main/Qwen3.5-0.8B_int8.litertlm",963L*1000*1000);
 static Spec choose(long physicalRamBytes){return physicalRamBytes>=5L*1024*1024*1024?QUALITY:LIGHT;}
}
