package vn.ca.vietvoiceoffline;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.net.*;
import android.os.*;
import android.provider.Settings;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;
import java.net.*;
import java.util.concurrent.*;

/**
 * Honest DNS controls for Android WebView: opens system Private DNS settings.
 * WebView has no public per-WebView DNS override. The selected preset is a guide,
 * not an applied setting. No traffic interception, TLS downgrading or VPN.
 */
final class BrowserDnsAssistant {
 private BrowserDnsAssistant(){}
 static void show(Activity a,WebView web,TextView status,SharedPreferences prefs){
  String[] items={"Tự động · dùng DNS hệ thống","Cloudflare · one.one.one.one","Google · dns.google","Kiểm tra DNS và kết nối trang","Tải lại trang"};
  new AlertDialog.Builder(a).setTitle("DNS • VietVoice Browser")
   .setMessage("DNS riêng là cài đặt của Android và ảnh hưởng đến cả Wi-Fi/4G/5G. VietVoice không thể tự thay đổi DNS hệ thống. Chọn nhà cung cấp để sao chép tên miền và mở cài đặt.")
   .setItems(items,(d,which)->{
    if(which==3){diagnose(a,web,status);return;}
    if(which==4){web.stopLoading();web.reload();return;}
    prefs.edit().putInt("dns_preset",which).apply();
    String hostname=BrowserDnsPolicy.privateDnsHost(which);
    String how=which==0?"Trong cài đặt DNS riêng, chọn Tự động rồi lưu.\n\nĐây không phải thay đổi tự động từ VietVoice.":
     "Tên máy chủ DNS: "+hostname+"\n\nChọn 'Tên máy chủ của nhà cung cấp DNS riêng', dán tên miền và bấm Lưu.\n\nAndroid sẽ dùng DNS đó cho cả thiết bị (trừ ngoại lệ như VPN).";
    AlertDialog.Builder b=new AlertDialog.Builder(a).setTitle("Thiết lập "+BrowserDnsPolicy.LABELS[which]).setMessage(how)
     .setPositiveButton(which==0?"Mở cài đặt DNS":"Sao chép & mở cài đặt",(dlg,v)->{
      if(!hostname.isEmpty()){
       ClipboardManager clipboard=(ClipboardManager)a.getSystemService(Context.CLIPBOARD_SERVICE);
       if(clipboard!=null)clipboard.setPrimaryClip(ClipData.newPlainText("DNS riêng",hostname));
      }
      openPrivateDnsSettings(a);
      status.setText("Đã mở cài đặt Android. Hãy lưu DNS tại đó rồi quay lại tải trang. VietVoice chưa tự thay đổi DNS.");
     }).setNegativeButton("Hủy",null);
    if(!hostname.isEmpty())b.setNeutralButton("Chỉ sao chép",(dlg,v)->{
     ClipboardManager clipboard=(ClipboardManager)a.getSystemService(Context.CLIPBOARD_SERVICE);
     if(clipboard!=null)clipboard.setPrimaryClip(ClipData.newPlainText("DNS riêng",hostname));
     Toast.makeText(a,"Đã chép "+hostname,Toast.LENGTH_SHORT).show();
    });
    b.show();
   }).setNegativeButton("Đóng",null).show();
 }
 static void openPrivateDnsSettings(Activity a){
  String[] actions={"android.settings.PRIVATE_DNS_SETTINGS",Settings.ACTION_WIRELESS_SETTINGS,Settings.ACTION_SETTINGS};
  for(String action:actions){try{a.startActivity(new Intent(action));return;}catch(Exception ignored){}}
  Toast.makeText(a,"Mở Cài đặt → Kết nối & chia sẻ → DNS riêng",Toast.LENGTH_LONG).show();
 }
 static void diagnose(Activity a,WebView web,TextView status){
  String url=web.getUrl();if(url==null||Uri.parse(url).getHost()==null)url="https://"+"example.com";
  String host=Uri.parse(url).getHost();
  if(host==null||host.isEmpty()){status.setText("Địa chỉ không có tên miền hợp lệ.");return;}
  status.setText("Đang kiểm tra DNS và cổng HTTPS của "+host+"…");
  final String target=host;
  new Thread(()->{
   StringBuilder report=new StringBuilder("Kiểm tra ").append(target).append("\n\n");
   ConnectivityManager cm=(ConnectivityManager)a.getSystemService(Context.CONNECTIVITY_SERVICE);
   try{
    if(cm!=null){Network active=cm.getActiveNetwork();LinkProperties link=active==null?null:cm.getLinkProperties(active);
     if(link!=null)report.append("DNS riêng: ").append(link.isPrivateDnsActive()?(link.getPrivateDnsServerName()==null?"đang bật (tự động)":link.getPrivateDnsServerName()):"không bật / dùng DNS mạng").append("\n");}
   }catch(Exception ignored){}
   try{
    // Timeout DNS via future: getAllByName itself may block on some networks.
    ExecutorService single=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"dns-check");t.setDaemon(true);return t;});
    try{
     Future<InetAddress[]> f=single.submit(()->InetAddress.getAllByName(target));
     InetAddress[] addresses=f.get(7,TimeUnit.SECONDS);
     if(addresses.length==0)throw new UnknownHostException(target);
     report.append("DNS: phân giải thành công → ").append(addresses[0].getHostAddress()).append("\n");
     try(Socket socket=new Socket()){
      socket.connect(new InetSocketAddress(addresses[0],443),5000);
      report.append("Cổng 443: có phản hồi TCP. Nếu trang vẫn lỗi, cần kiểm tra HTTPS hoặc chính website.");
     }catch(ConnectException e){report.append("Cổng 443: máy chủ từ chối kết nối. Đổi DNS có thể không giúp.");}
     catch(Exception e){report.append("Cổng 443: không kết nối được (").append(e.getClass().getSimpleName()).append("). Máy chủ hoặc mạng có thể đang chặn.");}
    }finally{single.shutdownNow();}
   }catch(UnknownHostException e){report.append("Không phân giải được DNS. Có thể thử DNS Cloudflare hoặc Google.");}
   catch(TimeoutException e){report.append("Truy vấn DNS quá thời gian. Kiểm tra Wi-Fi, 5G hoặc DNS riêng.");}
   catch(Exception e){report.append("Không kiểm tra được DNS: ").append(e.getClass().getSimpleName());}
   report.append("\n\nLưu ý: đây là phép thử mạng, không đảm bảo trang web cho phép truy cập.");
   String result=report.toString();a.runOnUiThread(()->{if(a.isFinishing()||a.isDestroyed())return;status.setText("Đã kiểm tra DNS • "+target);
    new AlertDialog.Builder(a).setTitle("Kết quả kiểm tra DNS").setMessage(result).setPositiveButton("Thử đổi DNS",(d,n)->show(a,web,status,a.getSharedPreferences("vv_browser",0))).setNegativeButton("Đóng",null).show();});
  },"vv-dns-network-check").start();
 }
}
