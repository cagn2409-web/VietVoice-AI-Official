package vn.ca.vietvoiceoffline;

/** DNS presets for Android Private DNS. Normal apps cannot silently change the OS resolver. */
final class BrowserDnsPolicy {
 static final String[] LABELS={"Tự động (DNS hệ thống)","Cloudflare (1.1.1.1)","Google DNS (8.8.8.8)"};
 static String privateDnsHost(int choice){
  if(choice==1)return "one.one.one.one";
  if(choice==2)return "dns.google";
  return "";
 }
 static String connectionExplanation(int error){
  // WebViewClient.ERROR_CONNECT is -6; DNS failure is -2.
  if(error==-6)return "Máy chủ từ chối kết nối. Đổi DNS thường không giải quyết lỗi này.";
  if(error==-2)return "Không phân giải được tên miền. Kiểm tra kết nối hoặc thử DNS khác.";
  if(error==-8)return "Kết nối bị quá thời gian. Kiểm tra mạng hoặc máy chủ.";
  return "Hãy kiểm tra DNS, mạng và tình trạng máy chủ.";
 }
 private BrowserDnsPolicy(){}
}
