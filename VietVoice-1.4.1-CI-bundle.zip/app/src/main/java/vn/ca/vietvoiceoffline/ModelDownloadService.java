package vn.ca.vietvoiceoffline;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Foreground dataSync download: survives leaving the Activity, supports resume after interruption. */
public final class ModelDownloadService extends Service {
 static final String ACTION_ALL="vn.ca.vietvoiceoffline.action.DOWNLOAD_ALL";
 static final String ACTION_MODEL="vn.ca.vietvoiceoffline.action.DOWNLOAD_MODEL";
 static final String ACTION_PAUSE="vn.ca.vietvoiceoffline.action.PAUSE_DOWNLOAD";
 private static final String CHANNEL="vietvoice_model_download";
 private static final int NOTIFICATION_ID=2103;
 private static final int FINISHED_ID=2104;
 private volatile Thread worker;
 private volatile boolean paused;
 private long lastNotification;
 private final Runnable onProgress=()->{
  if(State.downloading){
   getSharedPreferences("download_service",MODE_PRIVATE).edit().putString("last",State.setup).apply();
   long now=SystemClock.elapsedRealtime();
   if(now-lastNotification>=1200){lastNotification=now;showProgress();}
  }
 };

 static void start(Context context,boolean all){
  if(State.running||State.downloading)return;
  Intent i=new Intent(context,ModelDownloadService.class);
  i.setAction(all?ACTION_ALL:ACTION_MODEL);
  try{context.startForegroundService(i);}
  catch(RuntimeException ex){State.setup("Không thể bắt đầu tải nền: "+State.error(ex));}
 }
 @Override public void onCreate(){
  super.onCreate();
  NotificationChannel channel=new NotificationChannel(CHANNEL,"Tải model VietVoice",NotificationManager.IMPORTANCE_LOW);
  channel.setDescription("Tiến độ tải AI ở chế độ nền");
  ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
  State.listeners.addIfAbsent(onProgress);
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  String action=intent==null?ACTION_ALL:intent.getAction();
  if(ACTION_PAUSE.equals(action)){
   paused=true;Thread t=worker;if(t!=null)t.interrupt();
   State.setup("Đang tạm dừng tải. Bấm tải lại để tiếp tục từ phần đã có.");
   return START_NOT_STICKY;
  }
  if(worker!=null&&worker.isAlive())return START_REDELIVER_INTENT;
  if(State.running){stopSelf(startId);return START_NOT_STICKY;}
  final boolean all=!ACTION_MODEL.equals(action);
  paused=false;
  State.downloading=true;
  State.setup("Đang chuẩn bị tải AI ở chế độ nền. Bạn có thể rời ứng dụng.");
  Notification ongoing=makeNotification("Đang chuẩn bị model…",true);
  try{startForeground(NOTIFICATION_ID,ongoing,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);}
  catch(RuntimeException ex){State.downloading=false;State.setup("Lỗi dịch vụ tải nền: "+State.error(ex));stopSelf(startId);return START_NOT_STICKY;}
  getSharedPreferences("download_service",MODE_PRIVATE).edit().putBoolean("pending",true).apply();
  worker=new Thread(()->run(all,startId),"vietvoice-model-download");
  worker.start();
  return START_REDELIVER_INTENT;
 }
 private void run(boolean all,int startId){
  PowerManager.WakeLock lock=null;
  boolean success=false;
  try{
   PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
   if(pm!=null){lock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"VietVoice:ModelDownload");lock.acquire(3L*60*60*1000);}
   ModelStore.runDownload(getApplicationContext(),all);
   if(Thread.currentThread().isInterrupted()||paused)throw new IOException("Đã tạm dừng tải");
   success=true;
   State.setup(all?"Đã cài đủ AI. Mở VietVoice và bấm Bắt đầu dịch video.":"Model dịch đã được cài. Sẵn sàng dịch trực tiếp.");
  }catch(Exception e){
   State.setup(paused?"Đã tạm dừng. Mở VietVoice và bấm tải để tiếp tục.":"Tải bị gián đoạn: "+State.error(e)+". Bấm tải lại để tiếp tục.");
  }finally{
   if(lock!=null&&lock.isHeld())lock.release();
   getSharedPreferences("download_service",MODE_PRIVATE).edit().putBoolean("pending",!success).putString("last",State.setup).apply();
   State.downloading=false;State.changed();
   final String last=State.setup;
   final boolean done=success;
   State.main.post(()->{
    // Only stop this start request. A notification remains as the completion message.
    ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(FINISHED_ID,makeNotification(last,false));
    stopForeground(STOP_FOREGROUND_REMOVE);
    stopSelf(startId);
   });
  }
 }
 private Notification makeNotification(String message,boolean ongoing){
  Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  PendingIntent pending=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  Notification.Builder builder=new Notification.Builder(this,CHANNEL)
   .setSmallIcon(R.drawable.ic_voice)
   .setContentTitle(ongoing?"VietVoice · đang tải AI":"VietVoice · trạng thái tải AI")
   .setContentText(message.replace('\n',' ').trim())
   .setStyle(new Notification.BigTextStyle().bigText(message))
   .setContentIntent(pending).setOnlyAlertOnce(true).setOngoing(ongoing).setAutoCancel(!ongoing);
  if(ongoing){
   Intent stop=new Intent(this,ModelDownloadService.class).setAction(ACTION_PAUSE);
   PendingIntent pause=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
   builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,"Tạm dừng",pause).build());
   Matcher m=Pattern.compile("([0-9]{1,3})%").matcher(message);
   if(m.find())builder.setProgress(100,Math.min(100,Integer.parseInt(m.group(1))),false);
   else builder.setProgress(0,0,true);
  }
  return builder.build();
 }
 private void showProgress(){if(worker==null||!worker.isAlive())return;
  ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,makeNotification(State.setup,true));
 }
 @Override public void onTaskRemoved(Intent rootIntent){super.onTaskRemoved(rootIntent); /* Download intentionally continues. */}
 @Override public void onTimeout(int startId,int fgsType){
  paused=true;Thread t=worker;if(t!=null)t.interrupt();
  State.setup("Android giới hạn thời gian tải nền. Mở lại VietVoice và bấm tải để tiếp tục.");
  stopSelf(startId);
 }
 @Override public void onDestroy(){State.listeners.remove(onProgress);super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent intent){return null;}
}
