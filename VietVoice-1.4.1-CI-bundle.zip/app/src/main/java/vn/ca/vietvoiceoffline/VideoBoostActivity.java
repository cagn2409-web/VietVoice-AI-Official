package vn.ca.vietvoiceoffline;

import android.app.*;
import android.app.PictureInPictureParams;
import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import androidx.annotation.OptIn;
import androidx.media3.common.*;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.*;
import androidx.media3.datasource.cache.*;
import androidx.media3.database.StandaloneDatabaseProvider;
import androidx.media3.exoplayer.*;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import java.io.File;

/** Dedicated player for direct HTML5 media. Does not bypass DRM, blob or host throttling. */
@OptIn(markerClass = UnstableApi.class)
public final class VideoBoostActivity extends Activity {
 private static final long LIMIT=512L*1024*1024;
 private PlayerView playerView;
 private ExoPlayer player;
 private SimpleCache cache;
 private TextView stats,details;
 private Spinner bufferChoice;
 private Handler main=new Handler(Looper.getMainLooper());
 private long lastBytes,lastTick;private int rebufferCount;
 private final Runnable refresh=new Runnable(){@Override public void run(){updateStats();main.postDelayed(this,1200);}};
 private String url,referer,userAgent;
 private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
 private Button button(LinearLayout bar,String s,View.OnClickListener listener){Button b=new Button(this);b.setAllCaps(false);b.setTextSize(12);b.setText(s);b.setOnClickListener(listener);bar.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));return b;}
 @Override public void onCreate(Bundle state){super.onCreate(state);url=getIntent().getStringExtra("url");referer=getIntent().getStringExtra("referer");userAgent=getIntent().getStringExtra("ua");
  if(VideoUrlPolicy.acceptedUrl(url,url)==null){new AlertDialog.Builder(this).setMessage("Chỉ phát đường dẫn video HTTP(S) trực tiếp.").setPositiveButton("Đóng",(d,n)->finish()).show();return;}
  getWindow().setStatusBarColor(Color.rgb(16,45,55));LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xff071D23);setContentView(root);
  TextView title=new TextView(this);title.setText("VIETVOICE  ·  VIDEO BOOST PRO");title.setTextColor(0xffB2EEE5);title.setPadding(dp(14),dp(12),dp(8),dp(10));root.addView(title);
  playerView=new PlayerView(this);playerView.setUseController(true);root.addView(playerView,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout row=new LinearLayout(this);row.setBackgroundColor(0xff17343D);root.addView(row);
  button(row,"30s",v->setBuffer(30));button(row,"60s",v->setBuffer(60));button(row,"120s",v->setBuffer(120));button(row,"Mini",v->enterMini());
  LinearLayout row2=new LinearLayout(this);root.addView(row2);
  button(row2,"1×",v->speed(1));button(row2,"1.25×",v->speed(1.25f));button(row2,"1.5×",v->speed(1.5f));button(row2,"Xóa cache",v->clearCacheConfirm());
  stats=new TextView(this);stats.setTextSize(13);stats.setTextColor(Color.WHITE);stats.setPadding(dp(14),dp(8),dp(12),dp(4));root.addView(stats);
  details=new TextView(this);details.setTextSize(11);details.setTextColor(0xffBDD3D5);details.setPadding(dp(14),0,dp(12),dp(12));details.setText("Cache tối đa 512 MB • Chỉ luồng MP4/HLS/DASH trực tiếp • Không vượt giới hạn máy chủ.");root.addView(details);
  startPlayer(getSharedPreferences("video_boost",0).getInt("buffer",30),0,true);main.post(refresh);
 }
 private void startPlayer(int seconds,long position,boolean play){
  int target=VideoUrlPolicy.clampBufferSeconds(seconds);getSharedPreferences("video_boost",0).edit().putInt("buffer",target).apply();
  if(player!=null){playerView.setPlayer(null);player.release();player=null;}
  try{
   if(cache==null){File dir=new File(getCacheDir(),"vv-native-video-cache");cache=new SimpleCache(dir,new LeastRecentlyUsedCacheEvictor(LIMIT),new StandaloneDatabaseProvider(getApplicationContext()));}
   DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setConnectTimeoutMs(15000).setReadTimeoutMs(25000).setAllowCrossProtocolRedirects(false);
   if(userAgent!=null&&userAgent.length()<1000)http.setUserAgent(userAgent);
   // Do not forward cookies or arbitrary authentication tokens to a third-party video host.
   CacheDataSource.Factory factory=new CacheDataSource.Factory().setCache(cache).setUpstreamDataSourceFactory(http).setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);
   DefaultLoadControl load=new DefaultLoadControl.Builder().setBufferDurationsMs(Math.min(15000,target*1000),target*1000,1800,2800).setPrioritizeTimeOverSizeThresholds(true).build();
   player=new ExoPlayer.Builder(this).setLoadControl(load).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(factory)).build();
   player.addListener(new Player.Listener(){@Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_BUFFERING&&player!=null&&player.getCurrentPosition()>0)rebufferCount++;updateStats();}
     @Override public void onPlayerError(PlaybackException error){stats.setText("Không phát được luồng này: "+error.getErrorCodeName()+". Thử xem trực tiếp trên trang.");}});
   playerView.setPlayer(player);
   MediaItem item=MediaItem.fromUri(Uri.parse(url));player.setMediaItem(item);player.prepare();if(position>0)player.seekTo(position);player.setPlayWhenReady(play);
  }catch(Throwable e){stats.setText("Không mở được Video Boost: "+e.getMessage());}
 }
 private void setBuffer(int seconds){long at=player==null?0:player.getCurrentPosition();boolean playing=player!=null&&player.getPlayWhenReady();
   startPlayer(seconds,at,playing);updateStats();Toast.makeText(this,"Đã chọn mục tiêu đệm "+seconds+" giây",Toast.LENGTH_SHORT).show();}
 private void speed(float s){if(player!=null)player.setPlaybackSpeed(s);}
 private void updateStats(){if(stats==null||player==null)return;
  long buffered=Math.max(0,player.getBufferedPosition()-player.getCurrentPosition());long cacheMb=cache==null?0:cache.getCacheSpace()/1048576;
  int state=player.getPlaybackState();String stateLabel=state==Player.STATE_READY?"Đang phát":state==Player.STATE_BUFFERING?"Đang nạp":state==Player.STATE_ENDED?"Đã hết":"Chưa tải";
  stats.setText(stateLabel+"   •   Đệm trước: "+(buffered/1000)+" giây   •   Cache: "+cacheMb+"/512 MB   •   Tải lại: "+rebufferCount);
 }
 private void enterMini(){if(Build.VERSION.SDK_INT<26){Toast.makeText(this,"Máy không hỗ trợ cửa sổ nổi Android PiP",Toast.LENGTH_SHORT).show();return;}
  try{enterPictureInPictureMode(new PictureInPictureParams.Builder().build());}catch(Exception e){Toast.makeText(this,"Không thể mở Mini Player trên máy này",Toast.LENGTH_SHORT).show();}}
 private void clearCacheConfirm(){new AlertDialog.Builder(this).setTitle("Xóa đệm video")
  .setMessage("Xóa tối đa 512 MB dữ liệu video tạm? Video hiện tại sẽ tải lại từ đầu vị trí đang xem.")
  .setPositiveButton("Xóa",(d,n)->{long at=player==null?0:player.getCurrentPosition();boolean play=player!=null&&player.getPlayWhenReady();
   if(player!=null){playerView.setPlayer(null);player.release();player=null;}
   if(cache!=null){cache.release();cache=null;}try{SimpleCache.delete(new File(getCacheDir(),"vv-native-video-cache"),new StandaloneDatabaseProvider(getApplicationContext()));}
   catch(Exception ignored){}startPlayer(getSharedPreferences("video_boost",0).getInt("buffer",30),at,play);
  }).setNegativeButton("Hủy",null).show();}
 @Override public void onPictureInPictureModeChanged(boolean inPicture,android.content.res.Configuration config){super.onPictureInPictureModeChanged(inPicture,config);
  if(playerView!=null)playerView.setUseController(!inPicture);
 }
 @Override protected void onDestroy(){main.removeCallbacks(refresh);if(player!=null){playerView.setPlayer(null);player.release();player=null;}if(cache!=null){cache.release();cache=null;}super.onDestroy();}
}
