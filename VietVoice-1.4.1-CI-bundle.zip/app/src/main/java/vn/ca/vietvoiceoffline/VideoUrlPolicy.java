package vn.ca.vietvoiceoffline;

import java.net.URI;
import java.util.Locale;

/** Conservative HTML5 media handoff: never sniff DRM or bypass protected streams. */
final class VideoUrlPolicy {
 private VideoUrlPolicy(){}
 static String acceptedUrl(String page, String candidate) {
  if(candidate==null || candidate.trim().isEmpty() || candidate.length()>6000)return null;
  String c=candidate.trim();
  if(c.startsWith("blob:")||c.startsWith("data:")||c.startsWith("javascript:"))return null;
  try{
   URI base=new URI(page);URI resolved=base.resolve(new URI(c)).normalize();
   if(!"https".equalsIgnoreCase(resolved.getScheme())&& !"http".equalsIgnoreCase(resolved.getScheme()))return null;
   if(resolved.getHost()==null || resolved.getUserInfo()!=null)return null;
   String path=resolved.getPath().toLowerCase(Locale.ROOT);
   if(!(path.endsWith(".mp4")||path.endsWith(".m4v")||path.endsWith(".webm")||path.endsWith(".m3u8")||path.endsWith(".mpd")||path.endsWith(".mp3")))return null;
   return resolved.toString();
  }catch(Exception ignored){return null;}
 }
 static int clampBufferSeconds(int n){return n<=15?15:n<=30?30:n<=60?60:120;}
}
