package vn.ca.vietvoiceoffline;
import org.junit.Test;
import static org.junit.Assert.*;
public class AutoModelInstallerTest {
 @Test public void cleansValidLfsHash(){String sha="abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";assertEquals(sha,AutoModelInstaller.cleanSha("\""+sha.toUpperCase()+"\""));}
 @Test public void rejectsInvalidChecksum(){assertEquals("",AutoModelInstaller.cleanSha("abc"));assertEquals("",AutoModelInstaller.cleanSha(null));}
}
