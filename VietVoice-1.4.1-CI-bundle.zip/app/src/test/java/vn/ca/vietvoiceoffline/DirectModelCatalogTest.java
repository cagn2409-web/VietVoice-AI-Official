package vn.ca.vietvoiceoffline;
import org.junit.Test;
import static org.junit.Assert.*;
public class DirectModelCatalogTest {
 @Test public void lowRamChoosesSmall() {assertEquals("qwen3.5-0.8b-int8",DirectModelCatalog.choose(4L*1024*1024*1024).id);}
 @Test public void sixGbChoosesTranslationModel() {assertEquals("hy-mt2-1.8b-int8",DirectModelCatalog.choose(6L*1024*1024*1024).id);}
 @Test public void directDownloadUrlUsesHttpsAndLiteRtFormat() {for(DirectModelCatalog.Spec s:new DirectModelCatalog.Spec[]{DirectModelCatalog.LIGHT,DirectModelCatalog.QUALITY}){assertTrue(s.url.startsWith("https://huggingface.co/"));assertTrue(s.url.endsWith(".litertlm"));}}
 @Test public void knownFilesAreNotEnglishPivotModels(){assertTrue(DirectModelCatalog.QUALITY.display.contains("chuyên dịch trực tiếp"));}
}
