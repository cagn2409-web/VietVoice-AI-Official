package vn.ca.vietvoiceoffline;
import org.junit.Test;
import static org.junit.Assert.*;
public class BrowserDnsPolicyTest {
 @Test public void presetHostnamesCorrect(){
  assertEquals("",BrowserDnsPolicy.privateDnsHost(0));
  assertEquals("one.one.one.one",BrowserDnsPolicy.privateDnsHost(1));
  assertEquals("dns.google",BrowserDnsPolicy.privateDnsHost(2));
 }
 @Test public void refusedIsNotConfusedWithDnsFailure(){
  assertTrue(BrowserDnsPolicy.connectionExplanation(-6).contains("từ chối"));
  assertTrue(BrowserDnsPolicy.connectionExplanation(-2).contains("phân giải"));
 }
}
