package vn.ca.vietvoiceoffline;
import org.junit.Test;import static org.junit.Assert.*;
public class VideoUrlPolicyTest {
 @Test public void acceptsDirectHlsAndMp4(){assertEquals("https://a.example/video.mp4?token=123",VideoUrlPolicy.acceptedUrl("https://a.example/page","/video.mp4?token=123"));
 assertEquals("https://a.example/stream.m3u8",VideoUrlPolicy.acceptedUrl("https://a.example/page","https://a.example/stream.m3u8"));}
 @Test public void rejectsBlobDrmAndScripts(){assertNull(VideoUrlPolicy.acceptedUrl("https://a.example/","blob:https://a.example/abc"));
 assertNull(VideoUrlPolicy.acceptedUrl("https://a.example/","javascript:alert(1)"));assertNull(VideoUrlPolicy.acceptedUrl("https://a.example/","https://a.example/page.html"));}
 @Test public void clampsBuffers(){assertEquals(15,VideoUrlPolicy.clampBufferSeconds(3));assertEquals(60,VideoUrlPolicy.clampBufferSeconds(45));assertEquals(120,VideoUrlPolicy.clampBufferSeconds(200));}
}
