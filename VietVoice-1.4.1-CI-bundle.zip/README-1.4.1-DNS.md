# VietVoice 1.4.1 — DNS Assistant

- Trình duyệt có thêm nút **DNS**: Tự động / Cloudflare / Google / Kiểm tra mạng / Tải lại.
- Không tự thay đổi Private DNS vì Android không cung cấp quyền cho ứng dụng thông thường. Nút chọn cấu hình đưa hostname vào clipboard và mở trang cài đặt DNS riêng.
- Có công cụ kiểm tra DNS của mạng hiện tại và TCP 443, phân biệt DNS thất bại với máy chủ từ chối kết nối.
- Trên Xiaomi HyperOS, nếu intent DNS riêng không mở được, Android sẽ mở cài đặt Wi-Fi/mạng để người dùng tự vào Kết nối & chia sẻ → DNS riêng.
- Private DNS thay đổi toàn hệ thống; VPN hoặc chính sách mạng có thể ghi đè.
- Không vượt chặn, không bỏ TLS, không tự thay đổi host và không giả vờ đã thay DNS.
- Chế độ Video Boost, tải model nền và tất cả mô-đun AI của 1.4 vẫn giữ nguyên.
- Cần kiểm thử thực tế trên Redmi 13C/HyperOS. Lỗi `ERR_CONNECTION_REFUSED` không chắc do DNS.
