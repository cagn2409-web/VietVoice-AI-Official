# VietVoice AI 1.3 — tải model hoàn toàn trong ứng dụng

## Hướng dẫn người dùng
- Nhấn **TẢI VÀ CÀI TOÀN BỘ AI (1 LẦN BẤM)**.
- App tải Whisper/SenseVoice, dữ liệu OCR Nhật/Trung/Hàn, giọng Việt và **model dịch trực tiếp**.
- Model tự chọn theo RAM: **Hy-MT2 1.8B INT8** (~1.83 GB) cho máy đủ RAM; **Qwen3.5 0.8B INT8** (~963 MB) cho RAM thấp.
- Không mở trang web, không chọn file `.litertlm`, không chuyển sang tiếng Anh khi dịch.
- Giữ app mở khi tải, khuyến nghị Wi-Fi và cần chừa thêm khoảng 512 MB bộ nhớ trống ngoài dung lượng model. Tải gián đoạn có thể bấm lại để tiếp tục.
- Lúc phát video, Android vẫn có thể yêu cầu quyền ghi âm/chia sẻ màn hình do quy định bảo mật hệ thống.

## An toàn & trạng thái
- File tải qua HTTPS từ LiteRT Community tại Hugging Face, không chọn bản Gemma yêu cầu chấp nhận giấy phép.
- Trước khi cài, so dung lượng và SHA-256 được máy chủ Hugging Face cung cấp qua X-Linked-Etag.
- Nếu không xác minh được, giữ file cũ; tuyệt đối không hiển thị là đã cài.
- Tải xong **không đồng nghĩa đã xác minh chạy trên Redmi 13C**: cần nạp model LiteRT-LM và thử dịch thực tế để chứng nhận tương thích, chất lượng, hiệu năng.
- 10 mô-đun chuyên trách dùng các mô hình nền chia sẻ, không phải 10 LLM độc lập.

## Giới hạn
- Nếu Hugging Face chặn mạng hoặc thay đổi header, có thể báo lỗi rõ ràng và không tự cài file chưa xác thực.
- Máy 4 GB RAM chỉ dùng model nhỏ; tốc độ/chất lượng có thể yếu hơn model chuyên dịch.
- Đã thêm code tải tự động; APK mới phải được biên dịch và kiểm thử trước khi phát hành.

Nguồn model:
https://huggingface.co/litert-community/Hy-MT2-1.8B
https://huggingface.co/litert-community/Qwen3.5-0.8B
