# VietVoice AI 1.3.1 – tải model chạy nền

- Nút **TẢI VÀ CÀI TOÀN BỘ AI** và **TỰ TẢI MODEL DỊCH PHÙ HỢP** khởi động foreground service `dataSync`, không còn tải bằng thread phụ nằm ngoài service.
- Có thể rời ứng dụng, vuốt bỏ màn hình VietVoice hoặc tắt màn hình; dịch vụ tiếp tục tải bằng thông báo Android, và có nút **Tạm dừng**.
- Giữ lại file `.part` hoặc `.download` để lần bấm tiếp theo tiếp tục từ vị trí đã lưu. Không cần tự tìm file model.
- Có kiểm tra file tải bằng SHA-256 như bản 1.3. Mã nguồn vẫn không dùng ML Kit.
- Thực hiện từ thao tác bấm trong app; không yêu cầu mở lại app liên tục. Nếu thiết bị/OEM hạn chế hoạt động nền, mất kết nối, thiết bị khởi động lại, hoặc người dùng chọn **Buộc dừng**, có thể phải mở lại và bấm tải để tiếp tục.
- Android 15/SDK 35 giới hạn `dataSync` foreground service 6 giờ mỗi 24 giờ khi app ở nền; chương trình có xử lý timeout và giữ phần tải.
- Ứng dụng sẽ hiện tiến độ ở thông báo nếu được phép thông báo. Trên Android 13+ khi người dùng không cấp quyền thông báo, hệ thống có thể ẩn thông báo nhưng foreground service vẫn hoạt động theo chính sách hệ thống.
- Chưa kiểm chứng thực tế trên Redmi 13C; build CI kiểm tra unit tests, APK signature, zip alignment, không thay thế kiểm thử thiết bị.
